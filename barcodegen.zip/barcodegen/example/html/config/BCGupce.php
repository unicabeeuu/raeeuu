<?php
$classFile = 'BCGupce.php';
$className = 'BCGupce';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
