<?php
$classFile = 'BCGcodabar.php';
$className = 'BCGcodabar';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
