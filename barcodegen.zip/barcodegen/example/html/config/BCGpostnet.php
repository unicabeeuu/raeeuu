<?php
$classFile = 'BCGpostnet.php';
$className = 'BCGpostnet';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
