<p align="center"><a href="https://www.barcodebakery.com" target="_blank">
    <img src="https://www.barcodebakery.com/images/BCG-Logo-SQ-GitHub.svg">
</a></p>

This utility library is used to handle GS1 barcodes in [GS1-128][1].

Please visit the following repository:

* [barcode-php-1d][2]


[1]: https://www.barcodebakery.com/en/docs/php/barcode/gs1128/api
[2]: https://github.com/barcode-bakery/barcode-php-1d/
