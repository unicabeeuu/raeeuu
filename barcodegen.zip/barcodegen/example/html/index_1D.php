<?php
header('Location: BCGcode39.php');
