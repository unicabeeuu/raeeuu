<p align="center"><a href="https://www.barcodebakery.com" target="_blank">
    <img src="https://www.barcodebakery.com/images/BCG-Logo-SQ-GitHub.svg">
</a></p>

[Barcode Bakery][1] is library written in PHP, [.NET Standard][2] and Node.JS which allows you to generate barcodes on the fly on your server for displaying or saving.

This is the common base for generating all barcode types.

Please visit the following repository:

* [barcode-php-1d][3]


[1]: https://www.barcodebakery.com
[2]: https://github.com/barcode-bakery/barcode-dotnet-1d/
[3]: https://github.com/barcode-bakery/barcode-php-1d/
