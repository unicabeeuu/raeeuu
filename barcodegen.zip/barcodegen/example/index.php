<?php
header('Location: html/index_1D.php');
