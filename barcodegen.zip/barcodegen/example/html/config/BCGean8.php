<?php
$classFile = 'BCGean8.php';
$className = 'BCGean8';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
