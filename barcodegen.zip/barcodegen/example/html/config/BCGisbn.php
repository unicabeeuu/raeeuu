<?php
$classFile = 'BCGisbn.php';
$className = 'BCGisbn';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
