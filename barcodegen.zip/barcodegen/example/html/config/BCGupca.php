<?php
$classFile = 'BCGupca.php';
$className = 'BCGupca';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
