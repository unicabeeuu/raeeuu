<?php
$classFile = 'BCGupcext5.php';
$className = 'BCGupcext5';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '7.0.4';
